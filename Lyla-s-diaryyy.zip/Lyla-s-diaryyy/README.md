# Lyla-s-diaryyy

Website for **Lyla's Diary**, the AI drama storytelling brand of Liyana (Instagram: [@lylas.diary_](https://www.instagram.com/lylas.diary_/)).

A single static page: `index.html` plus an `assets/` folder. No build step.

## Files

- `index.html` - the whole site (HTML, CSS and JavaScript)
- `assets/lylas-character.webm` - the character animation (transparent WebM, all 64 frames, seamless loop)
- `assets/frames/f001.webp ... f064.webp` - the same animation as frames, used automatically in browsers that cannot play transparent WebM (for example Safari/iOS)

## Run locally

Use a local web server so the video and frames load (opening the file directly can block them):

```
python3 -m http.server 8000
```

Then open http://localhost:8000

## Publish with GitHub Pages

Repository Settings > Pages > Deploy from a branch > `main` / `(root)`.

## Settings to fill in later (bottom of `index.html`)

- `CONTACT_EMAIL` - email that receives story submissions. Empty on purpose; until it is set, the form says the story was not sent.
- `YOUTUBE_NAME` and `YOUTUBE_URL` - the YouTube channel. Empty on purpose; nothing is shown until both are set.
- `FPS` - animation speed of the frame fallback (currently 12).
